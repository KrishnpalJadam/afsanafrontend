// const BASE_URL = "https://ssknf82q-3001.inc1.devtunnels.ms/api/"  
// veni railway
// const BASE_URL = "https://afsanaproject-production.up.railway.app/api/" 

// sagarsir railaway
const BASE_URL = "https://afsana-backend-production-8d3e.up.railway.app/api/"   

export default BASE_URL

