import React from "react";

const Communication = () => {
  return <div>communication</div>;
};

export default Communication;
